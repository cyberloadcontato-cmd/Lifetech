#!/usr/bin/env bash
# Gera o APK debug. Requisitos: Node 20+, JDK 21 e Android SDK (Android Studio).
set -e
npm install
[ -d android ] || npx cap add android
npx @capacitor/assets generate --android
M=android/app/src/main/AndroidManifest.xml
if ! grep -q "android.permission.CAMERA" "$M"; then
  sed -i 's#<application#<uses-permission android:name="android.permission.CAMERA" />\n    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />\n    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />\n    <application#' "$M"
fi
npx cap sync android
(cd android && ./gradlew assembleDebug)
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
