# Lifetech Suporte – projeto Capacitor

- Nome do app: Lifetech Suporte
- Pacote: com.lifetech.suporte
- Permissões: câmera, leitura de fotos e vídeos, internet
- Ícones: resources/ (gerados para Android via @capacitor/assets)

## Gerar o APK (debug)
Requisitos: Node 20+, JDK 21, Android SDK (instalado com o Android Studio) e a variável ANDROID_HOME configurada.

    ./setup.sh

O APK sai em android/app/build/outputs/apk/debug/app-debug.apk

## Gerar APK/AAB assinado (para publicar)
1. Abra a pasta android/ no Android Studio.
2. Build > Generate Signed Bundle / APK.
3. Crie um keystore e guarde-o em local seguro (sem ele não há como atualizar o app).

## Alterar o app
Edite www/index.html e rode: npx cap sync android
